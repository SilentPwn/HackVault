const { Plugin, loadPrism } = require("obsidian");

const IPV4 = /\b(?:25[0-5]|2[0-4]\d|1?\d?\d)(?:\.(?:25[0-5]|2[0-4]\d|1?\d?\d)){3}(?:\/\d{1,2})?\b/;
const MAC = /\b(?:[0-9A-F]{2}:){5}[0-9A-F]{2}\b/i;
const CVE = /\bCVE-\d{4}-\d{4,}\b/i;
const URL = /\bhttps?:\/\/[^\s)'"]+/;
const CPE = /\bcpe:\/[^\s;,]+/;
const FINGERPRINT = /\b(?:[0-9a-f]{2}:){15,}[0-9a-f]{2}\b/i;

const GRAMMAR = {
  // The command itself, e.g. "$ sudo nmap -sC -sV -p- 10.10.10.10"
  command: {
    pattern: /^[ \t]*(?:[$#>][ \t]*)?(?:sudo[ \t]+)?nmap[ \t].*$/m,
    inside: {
      prompt: /^[ \t]*[$#>]/,
      bin: /\b(?:sudo|nmap)\b/,
      flag: { pattern: /(\s)--?[\w-]+(?:=\S+)?/, lookbehind: true },
      ip: IPV4,
    },
  },

  // Noise / status lines
  comment: /^(?:Starting Nmap|Nmap done|Read data files|Service detection performed|OS and Service detection performed|OS detection performed|Initiating|Completed|Scanning|Discovered open port|NSE:|Note:|Not shown:|All \d+ scanned ports|Some closed ports|Stats:|# Nmap|Other addresses|rDNS record).*$/m,

  report: {
    pattern: /^Nmap scan report for .*$/m,
    inside: {
      label: /^Nmap scan report for/,
      ip: IPV4,
      host: /[\w.-]+/,
    },
  },

  "host-up": {
    pattern: /^Host is (?:up|down).*$/m,
    inside: {
      latency: /\d+(?:\.\d+)?s(?= latency)/,
    },
  },

  "table-header": /^(?:PORT|HOP)[ \t]+.*$/m,

  // NSE script output: "| http-title: ..." and "|_ssl-date: ..."
  script: {
    pattern: /^\|.*$/m,
    inside: {
      pipe: /^\|_?/,
      "script-name": { pattern: /^([ \t]?)[\w.-]+:(?=\s|$)/, lookbehind: true },
      vuln: /\b(?:LIKELY VULNERABLE|VULNERABLE|EXPLOITABLE)\b/,
      url: URL,
      cve: CVE,
      fingerprint: FINGERPRINT,
      cpe: CPE,
      ip: IPV4,
      mac: MAC,
    },
  },

  // Port table rows: "22/tcp open ssh OpenSSH 8.2p1 Ubuntu"
  "port-line": {
    pattern: /^\d{1,5}\/(?:tcp|udp|sctp)[ \t]+\S.*$/m,
    inside: {
      port: {
        pattern: /^\d{1,5}\/(?:tcp|udp|sctp)/,
        inside: {
          "port-num": /^\d+/,
          "port-slash": /\//,
          proto: /[a-z]+/,
        },
      },
      "state-ambiguous": { pattern: /^(\s+)(?:open|closed)\|filtered\b/, lookbehind: true },
      "state-open": { pattern: /^(\s+)open\b/, lookbehind: true },
      "state-closed": { pattern: /^(\s+)closed\b/, lookbehind: true },
      "state-filtered": { pattern: /^(\s+)(?:un)?filtered\b/, lookbehind: true },
      "port-rest": {
        pattern: /^(\s+)\S.*/,
        lookbehind: true,
        inside: {
          service: /^\S+/,
          version: { pattern: /^(\s+)\S.*/, lookbehind: true },
        },
      },
    },
  },

  "service-info": {
    pattern: /^Service Info:.*$/m,
    inside: {
      cpe: CPE,
      key: /\b(?:Service Info|OSs?|Hosts?|CPE|Device)(?=:)/,
    },
  },

  key: /^(?:MAC Address|Device type|Running(?: \(JUST GUESSING\))?|OS CPE|OS details|Aggressive OS guesses|No exact OS matches for host|Network Distance|TCP Sequence Prediction|IP ID Sequence Generation|Uptime guess|Host script results|Warning|TRACEROUTE.*?)(?=:|$)/m,

  url: URL,
  cve: CVE,
  cpe: CPE,
  fingerprint: FINGERPRINT,
  mac: MAC,
  ip: IPV4,
};

function render(tokens, parent) {
  for (const t of tokens) {
    if (typeof t === "string") {
      parent.appendText(t);
      continue;
    }
    const span = parent.createSpan({ cls: ["token", t.type] });
    if (Array.isArray(t.content)) render(t.content, span);
    else if (typeof t.content === "string") span.appendText(t.content);
    else render([t.content], span);
  }
}

module.exports = class NmapHighlight extends Plugin {
  async onload() {
    const Prism = await loadPrism();
    Prism.languages.nmap = GRAMMAR;

    this.registerMarkdownCodeBlockProcessor("nmap", (source, el) => {
      const pre = el.createEl("pre", { cls: ["language-nmap", "nmap-block"] });
      const code = pre.createEl("code", { cls: "language-nmap" });
      render(Prism.tokenize(source, GRAMMAR), code);

      const btn = pre.createEl("button", { cls: "copy-code-button", text: "Copy" });
      btn.addEventListener("click", async () => {
        await navigator.clipboard.writeText(source);
        btn.setText("Copied!");
        window.setTimeout(() => btn.setText("Copy"), 1500);
      });
    });
  }
};

module.exports.GRAMMAR = GRAMMAR;
