const { Plugin, loadPrism } = require("obsidian");
const { ViewPlugin, Decoration } = require("@codemirror/view");

const IPV4 = /\b(?:25[0-5]|2[0-4]\d|1?\d?\d)(?:\.(?:25[0-5]|2[0-4]\d|1?\d?\d)){3}(?:\/\d{1,2})?\b/;
const MAC = /\b(?:[0-9A-F]{2}:){5}[0-9A-F]{2}\b/i;
const CVE = /\bCVE-\d{4}-\d{4,}\b/i;
const URL = /\bhttps?:\/\/[^\s)'"]+/;
const CPE = /\bcpe:\/[^\s;,]+/;
const FINGERPRINT = /\b(?:[0-9a-f]{2}:){15,}[0-9a-f]{2}\b/i;

const GRAMMAR = {
  // The command itself, e.g. "$ sudo nmap -sC -sV -p- 10.10.10.10"
  command: {
    pattern: /^[ \t]*(?:[$#>][ \t]*)?(?:sudo[ \t]+)?nmap[ \t].*$/m,
    inside: {
      prompt: /^[ \t]*[$#>]/,
      bin: /\b(?:sudo|nmap)\b/,
      flag: { pattern: /(\s)--?[\w-]+(?:=\S+)?/, lookbehind: true },
      ip: IPV4,
    },
  },

  // Noise / status lines
  comment: /^(?:Starting Nmap|Nmap done|Read data files|Service detection performed|OS and Service detection performed|OS detection performed|Initiating|Completed|Scanning|Discovered open port|NSE:|Note:|Not shown:|All \d+ scanned ports|Some closed ports|Stats:|# Nmap|Other addresses|rDNS record).*$/m,

  report: {
    pattern: /^Nmap scan report for .*$/m,
    inside: {
      label: /^Nmap scan report for/,
      ip: IPV4,
      host: /[\w.-]+/,
    },
  },

  "host-up": {
    pattern: /^Host is (?:up|down).*$/m,
    inside: {
      latency: /\d+(?:\.\d+)?s(?= latency)/,
    },
  },

  "table-header": /^(?:PORT|HOP)[ \t]+.*$/m,

  // NSE script output: "| http-title: ..." and "|_ssl-date: ..."
  script: {
    pattern: /^\|.*$/m,
    inside: {
      pipe: /^\|_?/,
      "script-name": { pattern: /^([ \t]?)[\w.-]+:(?=\s|$)/, lookbehind: true },
      vuln: /\b(?:LIKELY VULNERABLE|VULNERABLE|EXPLOITABLE)\b/,
      url: URL,
      cve: CVE,
      fingerprint: FINGERPRINT,
      cpe: CPE,
      ip: IPV4,
      mac: MAC,
    },
  },

  // Port table rows: "22/tcp open ssh OpenSSH 8.2p1 Ubuntu"
  "port-line": {
    pattern: /^\d{1,5}\/(?:tcp|udp|sctp)[ \t]+\S.*$/m,
    inside: {
      port: {
        pattern: /^\d{1,5}\/(?:tcp|udp|sctp)/,
        inside: {
          "port-num": /^\d+/,
          "port-slash": /\//,
          proto: /[a-z]+/,
        },
      },
      "state-ambiguous": { pattern: /^(\s+)(?:open|closed)\|filtered\b/, lookbehind: true },
      "state-open": { pattern: /^(\s+)open\b/, lookbehind: true },
      "state-closed": { pattern: /^(\s+)closed\b/, lookbehind: true },
      "state-filtered": { pattern: /^(\s+)(?:un)?filtered\b/, lookbehind: true },
      "port-rest": {
        pattern: /^(\s+)\S.*/,
        lookbehind: true,
        inside: {
          service: /^\S+/,
          version: { pattern: /^(\s+)\S.*/, lookbehind: true },
        },
      },
    },
  },

  "service-info": {
    pattern: /^Service Info:.*$/m,
    inside: {
      cpe: CPE,
      key: /\b(?:Service Info|OSs?|Hosts?|CPE|Device)(?=:)/,
    },
  },

  key: /^(?:MAC Address|Device type|Running(?: \(JUST GUESSING\))?|OS CPE|OS details|Aggressive OS guesses|No exact OS matches for host|Network Distance|TCP Sequence Prediction|IP ID Sequence Generation|Uptime guess|Host script results|Warning|TRACEROUTE.*?)(?=:|$)/m,

  url: URL,
  cve: CVE,
  cpe: CPE,
  fingerprint: FINGERPRINT,
  mac: MAC,
  ip: IPV4,
};

// Turn Prism's token tree into flat [from, to, type] ranges (nested ranges allowed).
function tokenRanges(Prism, text, offset) {
  const out = [];
  const walk = (tokens, pos) => {
    for (const t of tokens) {
      if (typeof t === "string") {
        pos += t.length;
        continue;
      }
      const len = t.length;
      out.push([pos, pos + len, t.type]);
      if (Array.isArray(t.content)) walk(t.content, pos);
      else if (typeof t.content !== "string") walk([t.content], pos);
      pos += len;
    }
  };
  walk(Prism.tokenize(text, GRAMMAR), offset);
  return out;
}

// Find ```nmap / ~~~nmap blocks in the editor document.
function findBlocks(doc) {
  const blocks = [];
  let open = null;
  for (let i = 1; i <= doc.lines; i++) {
    const line = doc.line(i);
    if (!open) {
      const m = /^[ \t]*(`{3,}|~{3,})[ \t]*nmap\b/i.exec(line.text);
      if (m) open = { fence: m[1], startLine: i + 1 };
    } else {
      const t = line.text.trim();
      if (t.length >= open.fence.length && t[0] === open.fence[0] && /^(`+|~+)$/.test(t)) {
        if (i > open.startLine) blocks.push({ from: open.startLine, to: i - 1 });
        open = null;
      }
    }
  }
  return blocks;
}

function buildEditorExtension(Prism) {
  const lineDeco = Decoration.line({ class: "nmap-line" });
  const markCache = new Map();
  const mark = (type) => {
    if (!markCache.has(type)) markCache.set(type, Decoration.mark({ class: "token " + type }));
    return markCache.get(type);
  };

  const build = (view) => {
    const doc = view.state.doc;
    const decos = [];
    const vpFrom = view.viewport.from;
    const vpTo = view.viewport.to;
    for (const b of findBlocks(doc)) {
      const from = doc.line(b.from).from;
      const to = doc.line(b.to).to;
      if (to < vpFrom || from > vpTo) continue;
      for (let i = b.from; i <= b.to; i++) decos.push(lineDeco.range(doc.line(i).from));
      for (const [a, z, type] of tokenRanges(Prism, doc.sliceString(from, to), from)) {
        if (z > a) decos.push(mark(type).range(a, z));
      }
    }
    return Decoration.set(decos, true);
  };

  return ViewPlugin.fromClass(
    class {
      constructor(view) {
        this.decorations = build(view);
      }
      update(u) {
        if (u.docChanged || u.viewportChanged) this.decorations = build(u.view);
      }
    },
    { decorations: (v) => v.decorations }
  );
}

module.exports = class NmapHighlight extends Plugin {
  async onload() {
    const Prism = await loadPrism();
    // Reading view: Obsidian highlights ```nmap blocks with Prism on its own once the language exists.
    Prism.languages.nmap = GRAMMAR;
    // Editor (Live Preview and Source mode): paint the same tokens onto the editable text.
    this.registerEditorExtension(buildEditorExtension(Prism));
  }

  onunload() {
    const Prism = window.Prism;
    if (Prism && Prism.languages) delete Prism.languages.nmap;
  }
};

module.exports.GRAMMAR = GRAMMAR;
module.exports.tokenRanges = tokenRanges;
module.exports.findBlocks = findBlocks;
