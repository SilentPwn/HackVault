local dns = require "dns"
local ipOps = require "ipOps"
local listop = require "listop"
local math = require "math"
local nmap = require "nmap"
local shortport = require "shortport"
local stdnse = require "stdnse"
local strbuf = require "strbuf"
local string = require "string"
local stringaux = require "stringaux"
local tab = require "tab"
local table = require "table"
local target = require "target"
local match = require "match"

description = [[
Requests a zone transfer (AXFR) from a DNS server.

The script sends an AXFR query to a DNS server. The domain to query is
determined by examining the name given on the command line, the DNS
server's hostname, or it can be specified with the
<code>dns-zone-transfer.domain</code> script argument. If the query is
successful all domains and domain types are returned along with common
type specific data (SOA/MX/NS/PTR/A).

This script can run at different phases of an Nmap scan:
* Script Pre-scanning: in this phase the script will run before any
Nmap scan and use the defined DNS server in the arguments. The script
arguments in this phase are: <code>dns-zone-transfer.server</code> the
DNS server to use, can be a hostname or an IP address and must be
specified. The <code>dns-zone-transfer.port</code> argument is optional
and can be used to specify the DNS server port.
* Script scanning: in this phase the script will run after the other
Nmap phases and against an Nmap discovered DNS server. If we don't
have the "true" hostname for the DNS server we cannot determine a
likely zone to perform the transfer on.

Useful resources
* DNS for rocket scientists: http://www.zytrax.com/books/dns/
* How the AXFR protocol works: http://cr.yp.to/djbdns/axfr-notes.html
]]

---
-- @args dns-zone-transfer.domain Domain to transfer.
-- @args dns-zone-transfer.server DNS server. If set, this argument will
--       enable the script for the "Script Pre-scanning phase".
-- @args dns-zone-transfer.port DNS server port, this argument concerns
--       the "Script Pre-scanning phase" and it's optional, the default
--       value is <code>53</code>.
-- @args newtargets  If specified, adds returned DNS records onto Nmap
--       scanning queue.
-- @args dns-zone-transfer.addall  If specified, adds all IP addresses
--       including private ones onto Nmap scanning queue when the
--       script argument <code>newtargets</code> is given. The default
--       behavior is to skip private IPs (non-routable).
--
-- @see dns-nsec-enum.nse
-- @see dns-nsec3-enum.nse
-- @see dns-ip6-arpa-scan.nse
-- @see dns-brute.nse
--
-- @output
-- 53/tcp   open     domain
-- |  dns-zone-transfer:
-- |  foo.com.            SOA     ns2.foo.com. piou.foo.com.
-- |  foo.com.            TXT
-- |  foo.com.            NS      ns1.foo.com.
-- |  foo.com.            NS      ns2.foo.com.
-- |  foo.com.            NS      ns3.foo.com.
-- |  foo.com.            A       127.0.0.1
-- |  foo.com.            MX      mail.foo.com.
-- |  anansie.foo.com.    A       127.0.0.2
-- |  dhalgren.foo.com.   A       127.0.0.3
-- |  drupal.foo.com.     CNAME
-- |  goodman.foo.com.    A       127.0.0.4 i
-- |  goodman.foo.com.    MX      mail.foo.com.
-- |  isaac.foo.com.      A       127.0.0.5
-- |  julie.foo.com.      A       127.0.0.6
-- |  mail.foo.com.       A       127.0.0.7
-- |  ns1.foo.com.        A       127.0.0.7
-- |  ns2.foo.com.        A       127.0.0.8
-- |  ns3.foo.com.        A       127.0.0.9
-- |  stubing.foo.com.    A       127.0.0.10
-- |  vicki.foo.com.      A       127.0.0.11
-- |  votetrust.foo.com.  CNAME
-- |  www.foo.com.        CNAME
-- |_ foo.com.            SOA     ns2.foo.com. piou.foo.com.
-- @usage
-- nmap --script dns-zone-transfer.nse \
--      --script-args dns-zone-transfer.domain=<domain>


author = "Eddie Bell"
license = "Same as Nmap--See https://nmap.org/book/man-legal.html"
categories = {'intrusive', 'discovery'}

-- DNS options
local dns_opts = {}

prerule = function()
  dns_opts.domain, dns_opts.server,
  dns_opts.port, dns_opts.addall = stdnse.get_script_args(
    {"dns-zone-transfer.domain", "dnszonetransfer.domain"},
    {"dns-zone-transfer.server", "dnszonetransfer.server"},
    {"dns-zone-transfer.port", "dnszonetransfer.port"},
    {"dns-zone-transfer.addall","dnszonetransfer.addall"}
  )

  if not dns_opts.domain then
    stdnse.verbose1("Skipping '%s' %s, 'dnszonetransfer.domain' argument is missing.", SCRIPT_NAME, SCRIPT_TYPE)
    return false
  end

  if not dns_opts.server then
    stdnse.verbose1("Skipping '%s' %s, 'dnszonetransfer.server' argument is missing.", SCRIPT_NAME, SCRIPT_TYPE)
    return false
  end

  return true
end

portrule = function(host, port)
  if shortport.portnumber(53, 'tcp')(host, port) then
    dns_opts.domain, dns_opts.addall = stdnse.get_script_args(
      {"dns-zone-transfer.domain", "dnszonetransfer.domain"},
      {"dns-zone-transfer.addall","dnszonetransfer.addall"}
    )

    if not dns_opts.domain then
      if host.targetname then
        dns_opts.domain = host.targetname
      elseif host.name ~= "" then
        dns_opts.domain = host.name
      else
        -- can't do anything without a hostname
        stdnse.debug3("Skipping '%s' %s, 'dnszonetransfer.domain' argument is missing.", SCRIPT_NAME, SCRIPT_TYPE)
        return false
      end
    end
    dns_opts.server = host.ip
    dns_opts.port = port.number
    return true
  end

  return false
end

--- DNS query and response types.
--@class table
--@name typetab
local typetab = { 'A', 'NS', 'MD', 'MF', 'CNAME', 'SOA', 'MB', 'MG', 'MR',
  'NULL', 'WKS', 'PTR', 'HINFO', 'MINFO', 'MX', 'TXT', 'RP', 'AFSDB', 'X25',
  'ISDN', 'RT', 'NSAP', 'NSAP-PTR', 'SIG', 'KEY', 'PX', 'GPOS', 'AAAA', 'LOC',
  'NXT', 'EID', 'NIMLOC', 'SRV', 'ATMA', 'NAPTR', 'KX', 'CERT', 'A6', 'DNAME',
  'SINK', 'OPT', 'APL', 'DS', 'SSHFP', 'IPSECKEY', 'RRSIG', 'NSEC', 'DNSKEY',
  'DHCID', 'NSEC3', 'NSEC3PARAM', 'TLSA', [55]='HIP', [56]='NINFO', [57]='RKEY',
  [58]='TALINK', [59]='CDS', [99]='SPF', [100]='UINFO', [101]='UID', [102]='GID',
  [103]='UNSPEC', [249]='TKEY', [250]='TSIG', [251]='IXFR', [252]='AXFR',
  [253]='MAILB', [254]='MAILA', [255]='ANY', [256]='ZXFR', [257]='CAA',
  [32768]='TA', [32769]='DLV',
}

--- Convert two bytes into a 16bit number.
--@param data String of data.
--@param idx Index in the string (first of two consecutive bytes).
--@return 16 bit number represented by the two bytes.
function bto16(data, idx)
  return (">I2"):unpack(data, idx)
end

--- Parse an RFC 1035 domain name.
--@param data String of data.
--@param offset Offset in the string to read the domain name.
function parse_domain(data, offset, targets)
  local offset, domain = dns.decStr(data, offset)
  if domain then
    targets[domain:lower()] = 1
  else
    domain = "<parse error>"
  end
  return offset, string.format("%s.", domain)
end

local function parse_num_domain(data, offset, targets)
  local number, domain
  number = bto16(data, offset)
  offset, domain = parse_domain(data, offset+2, targets)
  return offset, string.format("%d %s", number, domain)
end

local function parse_txt(data, offset)
  local field, offset = string.unpack("s1", data, offset)
  return offset, string.format('"%s"', field)
end

--- Retrieve type specific data (rdata) from dns packets
local RD = {
  A = function(data, offset, targets)
    local ip = ipOps.str_to_ip(data:sub(offset, offset+3))
    targets[ip] = 1
    return offset+4, ip
  end,
  NS = parse_domain,
  MD = parse_domain, -- obsolete per rfc1035, use MX
  MF = parse_domain, -- obsolete per rfc1035, use MX
  CNAME = parse_domain,
  SOA = function(data, offset, targets)
    local field, info
    info = strbuf.new()
    -- name server
    offset, field = parse_domain(data, offset, targets)
    info = info .. field;
    -- mail box
    offset, field = parse_domain(data, offset, targets)
    info = info .. field;
    -- ignore other values
    offset = offset + 20
    return offset, strbuf.dump(info, ' ')
  end,
  MB = parse_domain, -- experimental per RFC 1035
  MG = parse_domain, -- experimental per RFC 1035
  MR = parse_domain, -- experimental per RFC 1035
  --NULL -- RFC 1035 says anything can go in this field. Hex dump is good.
  WKS = function(data, offset, targets)
    local len, ip, proto, svcs
    len = bto16(data, offset-2) - 5 -- length of bit field
    ip = ipOps.str_to_ip(data:sub(offset, offset+3))
    targets[ip] = 1
    proto = string.byte(data, offset+4)
    offset = offset + 5
    svcs = {}
    local p = 0
    local bits = {128, 64, 32, 16, 8, 4, 2, 1}
    for i=0, len-1 do
      local n = string.byte(data, offset + i)
      for _, v in ipairs(bits) do
        if (v & n) > 0 then table.insert(svcs, p) end
        p = p + 1
      end
    end
    if proto == 6 then
      proto = "TCP"
    elseif proto == 17 then
      proto = "UDP"
    end
    return offset + len, string.format("%s %s %s", ip, proto, table.concat(svcs, " "))
  end,
  PTR = parse_domain,
  HINFO = function(data, offset)
    local cpu, os -- See RFC 1010 for standard values for these
    offset, cpu = parse_txt(data, offset)
    offset, os = parse_txt(data, offset)
    return offset, string.format("%s %s", cpu, os)
  end,
  MINFO = function(data, offset, targets)
    local rmailbx, emailbx
    offset, rmailbx = parse_domain(data, offset, targets)
    offset, emailbx = parse_domain(data, offset, targets)
    return offset, string.format("%s %s", rmailbx, emailbx)
  end,
  MX = parse_num_domain,
  TXT = parse_txt,
  RP = function(data, offset, targets)
    local mbox_dname, txt_dname
    offset, mbox_dname = parse_domain(data, offset, targets)
    offset, txt_dname = parse_domain(data, offset, targets)
    return offset, string.format("%s %s", mbox_dname, txt_dname)
  end,
  AFSDB = parse_num_domain,
  X25 = parse_txt,
  ISDN = function(data, offset)
    local addr, sa
    offset, addr = parse_txt(data, offset)
    offset, sa = parse_txt(data, offset)
    return offset, string.format("%s %s", addr, sa)
  end,
  RT = parse_num_domain,
  NSAP = function(data, offset)
    local field
    field, offset = string.unpack(">s2", data, offset - 2)
    return offset, ("0x%s"):format(stdnse.tohex(field))
  end,
  ["NSAP-PTR"] = parse_domain,
  --SIG KEY --obsolete RRs relating to DNSSEC
  PX = function(data, offset, targets)
    local preference, map822, mapx400
    preference = bto16(data, offset)
    offset, map822 = parse_domain(data, offset+2, targets)
    offset, mapx400 = parse_domain(data, offset, targets)
    return offset, string.format("%d %s %s", preference, map822, mapx400)
  end,
  GPOS = function(data, offset)
    local lat, long, alt
    offset, lat = parse_txt(data, offset)
    offset, long = parse_txt(data, offset)
    offset, alt = parse_txt(data, offset)
    return offset, string.format("%s %s %s", lat, long, alt)
  end,
  AAAA = function(data, offset, targets)
    local ip = ipOps.str_to_ip(data:sub(offset, offset+15))
    targets[ip] = 1
    return offset+16, ip
  end,
  LOC = function(data, offset)
    local version, siz, hp, vp, lat, lon, alt
    version = string.byte(data, offset)
    if version ~= 0 then
      stdnse.debug2("Unknown LOC RR version: %d", version)
      return offset, ''
    end
    siz = string.byte(data, offset+1)
    siz = (siz >> 4) * 10 ^ (siz & 0x0f) / 100
    hp = string.byte(data, offset+2)
    hp = (hp >> 4) * 10 ^ (hp & 0x0f) / 100
    vp = string.byte(data, offset+3)
    vp = (vp >> 4) * 10 ^ (vp & 0x0f) / 100
    offset = offset + 4
    lat, lon, alt, offset = string.unpack(">I4I4I4", data, offset)
    lat = (lat-2^31)/3600000 --degrees
    local latd = 'N'
    if lat < 0 then
      latd = 'S'
      lat = 0-lat
    end
    lon = (lon-2^31)/3600000 --degrees
    local lond = 'E'
    if lon < 0 then
      lond = 'W'
      lon = 0-lon
    end
    return offset, string.format("%f %s %f %s %dm %0.1fm %0.1fm %0.1fm",
      lat, latd, lon, lond, alt/100 - 100000, siz, hp, vp)
  end,
  --NXT --obsolete RR relating to DNSSEC
  --EID NIMLOC --related to Nimrod DARPA project (Patton1995)
  SRV = function(data, offset, targets)
    local priority, weight, port, info
    priority, weight, port, offset = string.unpack(">I2I2I2", data, offset)
    offset, info = parse_domain(data, offset, targets)
    return offset, string.format("%d %d %d %s", priority, weight, port, info)
  end,
  ATMA = function(data, offset) --http://www.broadband-forum.org/ftp/pub/approved-specs/af-saa-0069.000.pdf
    local format, address
    format = string.byte(data, offset) -- 0 or 1
    offset, address = parse_txt(data, offset+1)
    return offset, string.format("%d %s", format, address)
  end,
  NAPTR = function(data, offset, targets)
    local order, preference, flags, service, regexp, replacement
    order = bto16(data, offset)
    preference = bto16(data, offset+2)
    offset, flags = parse_txt(data, offset+4)
    offset, service = parse_txt(data, offset)
    offset, regexp = parse_txt(data, offset)
    offset, replacement = parse_domain(data, offset, targets)
    return offset, string.format('%d %d %s %s %s %s',
      order, preference, flags, service, regexp, replacement)
  end,
  KX = parse_num_domain,
  --CERT
  A6 = function(data, offset, targets) -- obsoleted by AAAA
    local prefix, addr, name
    prefix = string.byte(data, offset)
    local pbytes = prefix >> 3
    addr = ipOps.str_to_ip(string.rep("\000", pbytes) .. data:sub(offset+1, 16-pbytes))
    targets[addr] = 1
    offset, name = parse_domain(data, offset + 17 - pbytes, targets)
    return offset, string.format("%d %s %s", prefix, addr, name)
  end,
  DNAME = parse_domain,
  SINK = function(data, offset) -- https://tools.ietf.org/html/draft-eastlake-kitchen-sink-02
    local coding, subcoding, field
    coding = string.byte(data, offset)
    subcoding = string.byte(data, offset+1)
    field, offset = string.unpack("c" .. (bto16(data, offset-2)-2), data, offset+2)
    return offset, string.format("%d %d %s", coding, subcoding, stdnse.tohex(field))
  end,
  --OPT APL DS
  SSHFP = function(data, offset)
    local algorithm, fptype, fplen, fingerprint
    algorithm = string.byte(data, offset)
    fptype = string.byte(data, offset+1)
    fplen = bto16(data, offset-2) - 2
    offset = offset + 2
    fingerprint = stdnse.tohex(data:sub(offset, offset+fplen-1))
    return offset + fplen, string.format("%d %d %s", algorithm, fptype, fingerprint)
  end,
  --IPSECKEY RRSIG NSEC DNSKEY DHCID NSEC3 NSEC3PARAM
  TLSA = function(data, offset) -- https://tools.ietf.org/html/rfc6698
    local rdatalen, cert_usage, selector, match_type, offset = (">I2BBB"):unpack(data, offset-2)
    local usages = {[0] = "PKIX-TA", [1] = "PKIX-EE", [2] = "DANE-TA", [3] = "DANE-EE", [255] = "PrivCert"}
    cert_usage = usages[cert_usage] or cert_usage
    local selectors = {[0] = "Cert", [1] = "SPKI", [255] = "PrivSel"}
    selector = selectors[selector] or selector
    local matches = {[0] = "Full", [1] = "SHA2-256", [2] = "SHA2-512", [255] = "PrivMatch"}
    match_type = matches[match_type] or match_type
    local offend = offset + rdatalen - 3
    local assoc_data = stdnse.tohex(data:sub(offset, offend - 1))
    return offend, string.format("%s %s %s %s", cert_usage, selector, match_type, assoc_data)
  end,
  --HIP NINFO RKEY TALINK CDS
  SPF = parse_txt,
  --UINFO UID GID UNSPEC TKEY TSIG IXFR AXFR
}

function get_rdata(data, offset, ttype, targets)
  if typetab[ttype] == nil then
    return offset, ''
  elseif RD[typetab[ttype]] then
    return RD[typetab[ttype]](data, offset, targets)
  else
    local field
    field, offset = string.unpack(">s2", data, offset - 2)
    return offset, ("hex: %s"):format(stdnse.tohex(field))
  end
end

--- Get a single answer record from the current offset
function get_answer_record(table, data, offset, targets)
  local line, rdlen, ttype

  -- answer domain
  offset, line = parse_domain(data, offset, targets)
  table.domain = line
  targets[line:lower()] = 1

  -- answer record type
  ttype = bto16(data, offset)
  if not(typetab[ttype] == nil) then
    table.ttype = typetab[ttype]
  end

  -- length of type specific data
  rdlen = bto16(data, offset+8)

  -- extra data, ignore ttl and class
  offset, line =  get_rdata(data, offset+10, ttype, targets)
  if(line == '') then
    offset = offset + rdlen
    return false, offset
  else
    table.rdata = line
  end

  return true, offset
end

-- parse and save uniq records in the results table
function parse_uniq_records(results, record)
  if record.domain and not results['Node Names'][record.domain] then
    local str = string.gsub(record.domain, "^%s*(.-)%s*$", "%1")
    if not results['Node Names'][str] then
      results['Node Names'][str] = 1
    end
  end
  if record.ttype and record.rdata then
    if not results[record.ttype] then
      results[record.ttype] = {}
    end
    local str = string.gsub(record.rdata, "^%s*(.-)%s*$", "%1")
    if not results[record.ttype][str] then
      results[record.ttype][str] = 1
    end
  end
end

-- parse and save only valid records
function parse_records(number, data, results, offset)
  while number > 0 do
    local answer, st = {}
    st, offset = get_answer_record(answer, data, offset)
    if st then
      parse_uniq_records(results, answer)
    end
    number = number - 1
  end
  return offset
end

-- parse and save all records in order to dump them to output
function parse_records_table(number, data, table, offset, targets)
  local soa_seen = 0
  while number > 0 do
    local answer, st = {}
    st, offset = get_answer_record(answer, data, offset, targets)
    if st then
      if answer.domain then
        tab.add(table, 1, answer.domain)
      end
      if answer.ttype then
        tab.add(table, 2, answer.ttype)
        if answer.ttype == "SOA" then
          soa_seen = soa_seen + 1
        end
      end
      if answer.rdata then
        tab.add(table, 3, answer.rdata)
      end
      tab.nextrow(table)
    end
    number = number - 1
  end
  return offset, soa_seen
end

function dump_zone_info(table, data, targets)
  -- number of available records
  local id, f1, f2, questions, answers, auth_answers, add_answers, offset = string.unpack(">I2 B B I2 I2 I2 I2", data)
  if (f1 & 0xf8) ~= 0x80 then
    return false, "Not a response to a standard query"
  end
  if (f2 & 0x7f) ~= 0x00 then
    return false, "Not a success response"
  end

  if questions > 1 then
    return false, 'More then 1 question record, something has gone wrong'
  end

  if answers == 0 then
    return false, 'transfer successful but no records'
  end

  -- skip over the question section, we don't need it
  if questions == 1 then
    offset = parse_domain(data, offset, {})
    offset = offset + 4
  end

  -- parse all available resource records
  stdnse.debug3("parsing ANCOUNT == %d, NSCOUNT == %d, ARCOUNT == %d", answers, auth_answers, add_answers)
  local soa_seen = 0
  offset, soa_seen = parse_records_table(answers, data, table, offset, targets)
  offset = parse_records_table(auth_answers, data, table, offset, targets)
  offset = parse_records_table(add_answers, data, table, offset, targets)

  return true, soa_seen
end

action = function(host, port)
  if not dns_opts.domain then
    return stdnse.format_output(false,
      string.format("'%s' script needs a dnszonetransfer.domain argument.",
      SCRIPT_TYPE))
  end
  if not host then
    host = dns_opts.server
  end
  local proto = "tcp"
  if not port then
    port = dns_opts.port or 53
  else
    proto = port.protocol
  end

  local soc = nmap.new_socket()
  local catch = function() soc:close() end
  local try = nmap.new_try(catch)
  soc:set_timeout(4000)
  try(soc:connect(host, port))

  -- To find the domain portion, we issue a SOA request.
  local dnspacket = dns.newPacket()
  dns.addQuestion(dnspacket, dns_opts.domain:lower(), dns.types.SOA, dns.CLASS.IN)
  dnspacket.id = math.random(0xffff)
  local response = try(dns.sendPackets(dns.encode(dnspacket), host, port, 4000, 1, nil, proto))
  local soa_pkt = dns.decode(response[1].data)
  local name
  if #soa_pkt.answers > 0 then
    -- either it's a domain and the domain is in answer,
    name = soa_pkt.answers[1].dname
  elseif #soa_pkt.auth > 0 then
    -- or it's a hostname and the domain is in authority.
    name = soa_pkt.auth[1].dname
  end

  local req_id = '\222\173'
  local offset = 1
  name = dns.encodeFQDN(name)
  local pkt_len = #name + 16

  -- build axfr request
  local buf = strbuf.new()
  buf = buf .. '\000' .. string.char(pkt_len) .. req_id
  buf = buf .. '\000\000\000\001\000\000\000\000\000\000'
  buf = buf .. name .. '\000\252\000\001'
  try(soc:send(strbuf.dump(buf)))

  -- read all data returned. Common to have
  -- multiple packets from a single request
  local soa_count = 0
  local targets = {}
  local table = tab.new()
  repeat
    local status, data = soc:receive_buf(match.numbytes(2), true)
    if not status then break end
    local len = string.unpack(">I2", data)
    if len < 12 then break end
    status, data = soc:receive_buf(match.numbytes(len), true)
    if not status then break end
    local status, ret = dump_zone_info(table, data, targets)
    if not status then break end
    soa_count = soa_count + ret
  until soa_count > 1
  soc:close()

  local outstr = '\n' .. tab.dump(table)
  if target.ALLOW_NEW_TARGETS then
    local n = 0
    for t, _ in pairs(targets) do
      if dns_opts.addall or not ipOps.isPrivate(t) then
        local status, ret = target.add(t)
        if status then
          n = n + ret
        end
      end
    end
    outstr = outstr .. ("\nTotal new targets added to Nmap scan queue: %d."):format(n)
  end
  return table, outstr
end
